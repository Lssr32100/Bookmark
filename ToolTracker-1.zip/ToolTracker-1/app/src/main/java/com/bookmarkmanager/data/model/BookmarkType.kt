package com.bookmarkmanager.data.model

enum class BookmarkType {
    FREE,
    PAID,
    FREEMIUM
}